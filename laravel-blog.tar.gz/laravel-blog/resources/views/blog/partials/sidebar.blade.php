{{-- Sidebar Widget: Search --}}
<div class="sidebar-widget">
    <h4><i class="bi bi-search me-2"></i>Recherche</h4>
    <form action="{{ route('blog.search') }}" method="GET">
        <div class="input-group">
            <input type="search" name="q" class="form-control" placeholder="Rechercher..."
                   value="{{ request('q') }}" style="font-family:var(--mono);font-size:0.85rem">
            <button type="submit" class="btn-ink">
                <i class="bi bi-arrow-right"></i>
            </button>
        </div>
    </form>
</div>

{{-- Sidebar Widget: Categories --}}
<div class="sidebar-widget">
    <h4><i class="bi bi-folder me-2"></i>Catégories</h4>
    <ul class="list-unstyled mb-0">
        @foreach($categories as $cat)
        <li class="mb-2">
            <a href="{{ route('blog.category', $cat->slug) }}"
               class="d-flex align-items-center justify-content-between text-decoration-none"
               style="color:var(--ink);transition:color 0.2s">
                <span class="d-flex align-items-center gap-2">
                    <span style="width:10px;height:10px;background:{{ $cat->color }};border-radius:50%;flex-shrink:0"></span>
                    <span style="font-size:0.9rem">{{ $cat->name }}</span>
                </span>
                <span class="badge" style="background:var(--warm-white);color:var(--text-muted);font-family:var(--mono);font-size:0.7rem">
                    {{ $cat->posts_count }}
                </span>
            </a>
        </li>
        @endforeach
    </ul>
</div>

{{-- Sidebar Widget: Recent Posts --}}
@if(isset($recentPosts) && $recentPosts->count() > 0)
<div class="sidebar-widget">
    <h4><i class="bi bi-clock-history me-2"></i>Articles récents</h4>
    <ul class="list-unstyled mb-0">
        @foreach($recentPosts as $recent)
        <li class="mb-3 pb-3 {{ !$loop->last ? 'border-bottom' : '' }}">
            <a href="{{ route('blog.show', $recent->slug) }}" class="text-decoration-none" style="color:var(--ink)">
                <p class="mb-1" style="font-size:0.9rem;line-height:1.4;font-weight:500">
                    {{ Str::limit($recent->title, 50) }}
                </p>
                <small class="post-meta">
                    <i class="bi bi-calendar me-1"></i>{{ $recent->published_at?->format('d M Y') }}
                </small>
            </a>
        </li>
        @endforeach
    </ul>
</div>
@endif

{{-- Sidebar Widget: Newsletter --}}
<div class="sidebar-widget" style="background:var(--ink);color:white;border-color:var(--ink)">
    <h4 style="color:white;border-color:var(--accent)">
        <i class="bi bi-envelope me-2"></i>Newsletter
    </h4>
    <p style="font-size:0.85rem;color:rgba(255,255,255,0.7);margin-bottom:1rem">
        Recevez nos derniers articles directement dans votre boîte mail.
    </p>
    <form>
        <input type="email" class="form-control mb-2" placeholder="votre@email.com"
               style="background:rgba(255,255,255,0.1);border-color:rgba(255,255,255,0.2);color:white;font-family:var(--mono);font-size:0.85rem">
        <button type="submit" class="btn-accent w-100">
            <i class="bi bi-send me-1"></i>S'abonner
        </button>
    </form>
</div>
