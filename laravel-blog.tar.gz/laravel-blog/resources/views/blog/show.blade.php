@extends('layouts.app')

@section('title', $post->title)
@section('description', $post->excerpt ?? Str::limit(strip_tags($post->content), 160))

@section('content')

{{-- POST HEADER --}}
<header style="background:var(--ink);color:white;padding:3rem 0 2rem;border-bottom:4px solid {{ $post->category?->color ?? 'var(--accent)' }}">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                {{-- Breadcrumb --}}
                <nav class="mb-3" style="font-family:var(--mono);font-size:0.75rem">
                    <a href="{{ route('home') }}" style="color:rgba(255,255,255,0.6);text-decoration:none">
                        <i class="bi bi-house me-1"></i>Accueil
                    </a>
                    <span style="color:rgba(255,255,255,0.4)" class="mx-2">/</span>
                    @if($post->category)
                    <a href="{{ route('blog.category', $post->category->slug) }}"
                       style="color:rgba(255,255,255,0.6);text-decoration:none">
                        {{ $post->category->name }}
                    </a>
                    <span style="color:rgba(255,255,255,0.4)" class="mx-2">/</span>
                    @endif
                    <span style="color:rgba(255,255,255,0.8)">{{ Str::limit($post->title, 30) }}</span>
                </nav>

                {{-- Category Badge --}}
                @if($post->category)
                <span class="badge-category d-inline-block mb-3" style="background:{{ $post->category->color }}">
                    {{ $post->category->name }}
                </span>
                @endif

                {{-- Title --}}
                <h1 style="font-family:var(--serif);font-size:clamp(1.8rem,4vw,2.5rem);margin-bottom:1rem;line-height:1.2">
                    {{ $post->title }}
                </h1>

                {{-- Excerpt --}}
                @if($post->excerpt)
                <p style="font-size:1.1rem;color:rgba(255,255,255,0.8);margin-bottom:1.5rem;line-height:1.6">
                    {{ $post->excerpt }}
                </p>
                @endif

                {{-- Meta --}}
                <div class="d-flex flex-wrap align-items-center gap-3 post-meta" style="color:rgba(255,255,255,0.6)">
                    <span class="d-flex align-items-center gap-2">
                        <div style="width:32px;height:32px;background:var(--accent);border-radius:50%;display:flex;align-items:center;justify-content:center">
                            <i class="bi bi-person-fill" style="color:white;font-size:0.9rem"></i>
                        </div>
                        <span>{{ $post->author->name }}</span>
                    </span>
                    <span><i class="bi bi-calendar me-1"></i>{{ $post->published_at?->format('d M Y') }}</span>
                    <span><i class="bi bi-clock me-1"></i>{{ $post->reading_time }} min de lecture</span>
                    <span><i class="bi bi-eye me-1"></i>{{ number_format($post->views) }} vues</span>
                    <span><i class="bi bi-chat me-1"></i>{{ $post->approvedComments->count() }} commentaire{{ $post->approvedComments->count() > 1 ? 's' : '' }}</span>
                </div>
            </div>
        </div>
    </div>
</header>

{{-- MAIN CONTENT --}}
<div class="container py-5">
    <div class="row g-5">
        {{-- ARTICLE --}}
        <div class="col-lg-8">
            {{-- Cover Image --}}
            @if($post->cover_image)
            <figure class="mb-4">
                <img src="{{ asset('storage/'.$post->cover_image) }}"
                     class="img-fluid w-100"
                     style="border:1.5px solid var(--border)"
                     alt="{{ $post->title }}">
            </figure>
            @endif

            {{-- Article Content --}}
            <article class="mb-5" style="background:white;border:1.5px solid var(--border);padding:2rem">
                <div style="font-size:1.05rem;line-height:1.8;color:var(--ink)">
                    {!! $post->content !!}
                </div>

                {{-- Tags/Share --}}
                <div class="mt-4 pt-4" style="border-top:1.5px solid var(--border)">
                    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                        @if($post->category)
                        <div>
                            <span class="post-meta">Catégorie :</span>
                            <a href="{{ route('blog.category', $post->category->slug) }}"
                               class="badge-category ms-2"
                               style="background:{{ $post->category->color }};color:white;text-decoration:none">
                                {{ $post->category->name }}
                            </a>
                        </div>
                        @endif
                        <div class="d-flex gap-2">
                            <span class="post-meta me-2">Partager :</span>
                            <a href="https://twitter.com/share?url={{ urlencode(request()->url()) }}&text={{ urlencode($post->title) }}"
                               target="_blank"
                               style="width:32px;height:32px;background:var(--ink);color:white;display:flex;align-items:center;justify-content:center;text-decoration:none">
                                <i class="bi bi-twitter-x"></i>
                            </a>
                            <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(request()->url()) }}"
                               target="_blank"
                               style="width:32px;height:32px;background:var(--ink);color:white;display:flex;align-items:center;justify-content:center;text-decoration:none">
                                <i class="bi bi-facebook"></i>
                            </a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url={{ urlencode(request()->url()) }}&title={{ urlencode($post->title) }}"
                               target="_blank"
                               style="width:32px;height:32px;background:var(--ink);color:white;display:flex;align-items:center;justify-content:center;text-decoration:none">
                                <i class="bi bi-linkedin"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </article>

            {{-- COMMENTS SECTION --}}
            <section id="comments" style="background:white;border:1.5px solid var(--border);padding:2rem">
                <h3 style="font-family:var(--serif);font-size:1.3rem;margin-bottom:1.5rem">
                    <i class="bi bi-chat-dots me-2" style="color:var(--accent)"></i>
                    Commentaires ({{ $post->approvedComments->count() }})
                </h3>

                {{-- Flash Messages --}}
                @if(session('success'))
                <div class="alert alert-success mb-4">
                    <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
                </div>
                @endif

                {{-- Comment Form --}}
                <form action="{{ route('blog.comment.store', $post->id) }}" method="POST" class="mb-4">
                    @csrf
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label post-meta">Nom *</label>
                            <input type="text" name="author_name"
                                   class="form-control @error('author_name') is-invalid @enderror"
                                   value="{{ old('author_name') }}" required>
                            @error('author_name')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label post-meta">Email *</label>
                            <input type="email" name="author_email"
                                   class="form-control @error('author_email') is-invalid @enderror"
                                   value="{{ old('author_email') }}" required>
                            @error('author_email')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-12">
                            <label class="form-label post-meta">Commentaire *</label>
                            <textarea name="content" rows="4"
                                      class="form-control @error('content') is-invalid @enderror"
                                      required>{{ old('content') }}</textarea>
                            @error('content')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn-accent">
                                <i class="bi bi-send me-1"></i>Publier le commentaire
                            </button>
                            <small class="text-muted ms-3" style="font-family:var(--mono);font-size:0.75rem">
                                Les commentaires sont modérés avant publication.
                            </small>
                        </div>
                    </div>
                </form>

                {{-- Comments List --}}
                @if($post->approvedComments->count() > 0)
                <div class="mt-4 pt-4" style="border-top:1.5px solid var(--border)">
                    @foreach($post->approvedComments as $comment)
                    <div class="d-flex gap-3 {{ !$loop->last ? 'mb-4 pb-4 border-bottom' : '' }}">
                        <div style="width:48px;height:48px;background:var(--ink);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <span style="color:white;font-family:var(--mono);font-size:1rem;font-weight:600">
                                {{ strtoupper(substr($comment->author_name, 0, 1)) }}
                            </span>
                        </div>
                        <div class="flex-grow-1">
                            <div class="d-flex align-items-center gap-2 mb-2">
                                <strong style="font-size:0.95rem">{{ $comment->author_name }}</strong>
                                <span class="post-meta">{{ $comment->created_at->diffForHumans() }}</span>
                            </div>
                            <p class="mb-0" style="font-size:0.95rem;line-height:1.6;color:var(--ink)">
                                {{ $comment->content }}
                            </p>
                        </div>
                    </div>
                    @endforeach
                </div>
                @else
                <div class="text-center py-4" style="background:var(--warm-white)">
                    <i class="bi bi-chat-square-text text-muted" style="font-size:2rem"></i>
                    <p class="text-muted mt-2 mb-0">Soyez le premier à commenter cet article !</p>
                </div>
                @endif
            </section>

            {{-- RELATED POSTS --}}
            @if($related->count() > 0)
            <section class="mt-5">
                <h3 style="font-family:var(--serif);font-size:1.3rem;margin-bottom:1.5rem">
                    <i class="bi bi-link-45deg me-2" style="color:var(--accent)"></i>
                    Articles similaires
                </h3>
                <div class="row g-4">
                    @foreach($related as $rel)
                    <div class="col-md-6">
                        <article class="post-card">
                            @if($rel->cover_image)
                            <img src="{{ asset('storage/'.$rel->cover_image) }}"
                                 class="card-img-top" alt="{{ $rel->title }}" style="height:150px">
                            @else
                            <div class="card-img-placeholder" style="height:150px">
                                <i class="bi bi-journal-text"></i>
                            </div>
                            @endif
                            <div class="card-body">
                                <h4 class="card-title" style="font-size:1rem">
                                    <a href="{{ route('blog.show', $rel->slug) }}">{{ Str::limit($rel->title, 50) }}</a>
                                </h4>
                            </div>
                            <div class="card-footer">
                                <div class="post-meta d-flex justify-content-between">
                                    <span>{{ $rel->published_at?->format('d M Y') }}</span>
                                    <span><i class="bi bi-clock me-1"></i>{{ $rel->reading_time }}min</span>
                                </div>
                            </div>
                        </article>
                    </div>
                    @endforeach
                </div>
            </section>
            @endif
        </div>

        {{-- SIDEBAR --}}
        <div class="col-lg-4">
            @include('blog.partials.sidebar', ['categories' => $categories, 'recentPosts' => $related])
        </div>
    </div>
</div>

@endsection
