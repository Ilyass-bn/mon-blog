@extends('layouts.app')

@section('title', $category->name)
@section('description', $category->description ?? 'Articles dans la catégorie ' . $category->name)

@section('content')

{{-- CATEGORY HEADER --}}
<div style="background:var(--ink);color:white;padding:3rem 0 2rem;border-bottom:4px solid {{ $category->color }}">
    <div class="container">
        <div class="d-flex align-items-center gap-3 mb-2">
            <a href="{{ route('home') }}" style="color:rgba(255,255,255,0.5);font-family:var(--mono);font-size:0.75rem;text-decoration:none">
                <i class="bi bi-house me-1"></i>Accueil
            </a>
            <span style="color:rgba(255,255,255,0.3)">/</span>
            <span style="color:rgba(255,255,255,0.5);font-family:var(--mono);font-size:0.75rem">Catégorie</span>
        </div>
        <div class="d-flex align-items-center gap-3">
            <div style="width:16px;height:16px;background:{{ $category->color }};border-radius:50%;flex-shrink:0"></div>
            <h1 style="font-family:var(--serif);font-size:clamp(1.8rem,4vw,2.5rem);margin:0">{{ $category->name }}</h1>
        </div>
        @if($category->description)
            <p style="color:rgba(255,255,255,0.65);margin-top:0.75rem;font-size:1rem;max-width:600px">
                {{ $category->description }}
            </p>
        @endif
        <div style="font-family:var(--mono);font-size:0.72rem;color:rgba(255,255,255,0.4);margin-top:0.75rem">
            {{ $posts->total() }} article{{ $posts->total() > 1 ? 's' : '' }}
        </div>
    </div>
</div>

{{-- ARTICLES --}}
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="row g-4">
                @forelse($posts as $post)
                <div class="col-md-6">
                    <article class="post-card">
                        @if($post->cover_image)
                            <img src="{{ asset('storage/'.$post->cover_image) }}"
                                 class="card-img-top" alt="{{ $post->title }}">
                        @else
                            <div class="card-img-placeholder">
                                <i class="bi bi-journal-text"></i>
                            </div>
                        @endif

                        <div class="card-body">
                            <h3 class="card-title">
                                <a href="{{ route('blog.show', $post->slug) }}">{{ $post->title }}</a>
                            </h3>
                            @if($post->excerpt)
                                <p class="text-muted" style="font-size:0.9rem;line-height:1.6">
                                    {{ Str::limit($post->excerpt, 100) }}
                                </p>
                            @endif
                        </div>

                        <div class="card-footer">
                            <div class="post-meta d-flex align-items-center justify-content-between">
                                <span><i class="bi bi-person me-1"></i>{{ $post->author->name }}</span>
                                <div class="d-flex gap-2">
                                    <span><i class="bi bi-eye me-1"></i>{{ $post->views }}</span>
                                    <span><i class="bi bi-clock me-1"></i>{{ $post->reading_time }}min</span>
                                </div>
                            </div>
                            <div class="mt-2 d-flex align-items-center justify-content-between">
                                <small class="post-meta">{{ $post->published_at?->format('d M Y') }}</small>
                                <a href="{{ route('blog.show', $post->slug) }}" class="btn-ink"
                                   style="text-decoration:none;font-size:0.7rem;padding:0.35rem 0.8rem">
                                    Lire <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                @empty
                <div class="col-12">
                    <div class="text-center py-5" style="background:var(--warm-white);border:1.5px dashed var(--border)">
                        <i class="bi bi-journal-x display-3 text-muted"></i>
                        <p class="mt-3 text-muted">Aucun article dans cette catégorie pour le moment.</p>
                        <a href="{{ route('home') }}" class="btn-ink mt-2" style="text-decoration:none">
                            Retour à l'accueil
                        </a>
                    </div>
                </div>
                @endforelse
            </div>

            @if($posts->hasPages())
            <div class="d-flex justify-content-center mt-4">
                {{ $posts->links() }}
            </div>
            @endif
        </div>

        {{-- SIDEBAR --}}
        <div class="col-lg-4">
            @include('blog.partials.sidebar', ['categories' => $categories, 'recentPosts' => $recentPosts])
        </div>
    </div>
</div>

@endsection
