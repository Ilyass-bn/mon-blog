@extends('layouts.app')

@section('title', $q ? 'Recherche : ' . $q : 'Recherche')

@section('content')

<div style="background:var(--ink);color:white;padding:2.5rem 0 2rem;border-bottom:4px solid var(--accent)">
    <div class="container">
        <h1 style="font-family:var(--serif);font-size:clamp(1.6rem,3.5vw,2.2rem);margin-bottom:0.75rem">
            @if($q)
                Résultats pour « {{ $q }} »
            @else
                Recherche
            @endif
        </h1>
        <p style="color:rgba(255,255,255,0.5);font-family:var(--mono);font-size:0.75rem">
            {{ $posts->total() }} résultat{{ $posts->total() > 1 ? 's' : '' }} trouvé{{ $posts->total() > 1 ? 's' : '' }}
        </p>

        {{-- Search bar --}}
        <form action="{{ route('blog.search') }}" method="GET" class="d-flex mt-3" style="max-width:480px">
            <input class="form-control"
                   style="border-radius:0;border:1.5px solid rgba(255,255,255,0.3);background:rgba(255,255,255,0.08);color:white;font-family:var(--mono);font-size:0.85rem"
                   type="search" name="q" placeholder="Nouvelle recherche…" value="{{ $q }}">
            <button type="submit" style="background:var(--accent);color:white;border:none;padding:0 1rem;font-family:var(--mono);font-size:0.8rem">
                <i class="bi bi-search"></i>
            </button>
        </form>
    </div>
</div>

<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="row g-4">
                @forelse($posts as $post)
                <div class="col-md-6">
                    <article class="post-card">
                        @if($post->cover_image)
                            <img src="{{ asset('storage/'.$post->cover_image) }}"
                                 class="card-img-top" alt="{{ $post->title }}">
                        @else
                            <div class="card-img-placeholder">
                                <i class="bi bi-journal-text"></i>
                            </div>
                        @endif

                        <div class="card-body">
                            @if($post->category)
                                <a href="{{ route('blog.category', $post->category->slug) }}"
                                   class="badge-category d-inline-block mb-2"
                                   style="background:{{ $post->category->color }};color:white;text-decoration:none">
                                    {{ $post->category->name }}
                                </a>
                            @endif

                            <h3 class="card-title">
                                <a href="{{ route('blog.show', $post->slug) }}">{{ $post->title }}</a>
                            </h3>

                            @if($post->excerpt)
                                <p class="text-muted" style="font-size:0.9rem;line-height:1.6">
                                    {{ Str::limit($post->excerpt, 100) }}
                                </p>
                            @endif
                        </div>

                        <div class="card-footer">
                            <div class="post-meta d-flex align-items-center justify-content-between">
                                <span><i class="bi bi-person me-1"></i>{{ $post->author->name }}</span>
                                <span><i class="bi bi-clock me-1"></i>{{ $post->reading_time }}min</span>
                            </div>
                            <div class="mt-2 d-flex align-items-center justify-content-between">
                                <small class="post-meta">{{ $post->published_at?->format('d M Y') }}</small>
                                <a href="{{ route('blog.show', $post->slug) }}" class="btn-ink"
                                   style="text-decoration:none;font-size:0.7rem;padding:0.35rem 0.8rem">
                                    Lire <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                @empty
                <div class="col-12">
                    <div class="text-center py-5" style="background:var(--warm-white);border:1.5px dashed var(--border)">
                        <i class="bi bi-search display-3 text-muted"></i>
                        <p class="mt-3 text-muted">
                            @if($q)
                                Aucun article ne correspond à « <strong>{{ $q }}</strong> ».
                            @else
                                Entrez un terme de recherche ci-dessus.
                            @endif
                        </p>
                        <a href="{{ route('home') }}" class="btn-ink mt-2" style="text-decoration:none">
                            Retour à l'accueil
                        </a>
                    </div>
                </div>
                @endforelse
            </div>

            @if($posts->hasPages())
            <div class="d-flex justify-content-center mt-4">
                {{ $posts->links() }}
            </div>
            @endif
        </div>

        {{-- SIDEBAR --}}
        <div class="col-lg-4">
            @include('blog.partials.sidebar', ['categories' => $categories, 'recentPosts' => $recentPosts])
        </div>
    </div>
</div>

@endsection
