@extends('layouts.app')

@section('title', 'Accueil')
@section('description', 'Découvrez nos derniers articles sur la technologie, le design et le développement.')

@section('content')

{{-- FEATURED SECTION --}}
@if($featured->count() > 0)
<section style="background:var(--ink);padding:3rem 0 2rem">
    <div class="container">
        <div class="d-flex align-items-center gap-2 mb-3">
            <span style="background:var(--accent);color:white;font-family:var(--mono);font-size:0.7rem;padding:0.3rem 0.6rem;text-transform:uppercase">
                <i class="bi bi-star-fill me-1"></i>À la une
            </span>
        </div>

        <div class="row g-4">
            {{-- Main Featured --}}
            @if($featured->first())
            @php $main = $featured->first(); @endphp
            <div class="col-lg-8">
                <a href="{{ route('blog.show', $main->slug) }}" class="text-decoration-none">
                    <div class="featured-hero" style="background-image:url('{{ $main->cover_image ? asset('storage/'.$main->cover_image) : '' }}');background-color:var(--ink-light)">
                        <div class="featured-hero-content">
                            @if($main->category)
                            <span class="badge-category d-inline-block mb-2" style="background:{{ $main->category->color }}">
                                {{ $main->category->name }}
                            </span>
                            @endif
                            <h2 style="font-family:var(--serif);font-size:clamp(1.5rem,3vw,2rem);margin-bottom:0.5rem">
                                {{ $main->title }}
                            </h2>
                            <p style="color:rgba(255,255,255,0.8);font-size:0.95rem;margin-bottom:0.75rem">
                                {{ Str::limit($main->excerpt, 120) }}
                            </p>
                            <div class="post-meta" style="color:rgba(255,255,255,0.6)">
                                <span><i class="bi bi-person me-1"></i>{{ $main->author->name }}</span>
                                <span class="mx-2">•</span>
                                <span><i class="bi bi-clock me-1"></i>{{ $main->reading_time }} min</span>
                                <span class="mx-2">•</span>
                                <span>{{ $main->published_at?->format('d M Y') }}</span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            @endif

            {{-- Side Featured --}}
            <div class="col-lg-4">
                <div class="d-flex flex-column gap-3 h-100">
                    @foreach($featured->skip(1)->take(3) as $feat)
                    <a href="{{ route('blog.show', $feat->slug) }}"
                       class="d-flex gap-3 p-3 text-decoration-none"
                       style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);transition:background 0.2s"
                       onmouseover="this.style.background='rgba(255,255,255,0.1)'"
                       onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                        @if($feat->cover_image)
                        <img src="{{ asset('storage/'.$feat->cover_image) }}"
                             style="width:80px;height:80px;object-fit:cover;flex-shrink:0"
                             alt="{{ $feat->title }}">
                        @else
                        <div style="width:80px;height:80px;background:var(--ink-light);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <i class="bi bi-journal-text" style="color:rgba(255,255,255,0.3)"></i>
                        </div>
                        @endif
                        <div>
                            @if($feat->category)
                            <span style="font-family:var(--mono);font-size:0.65rem;color:{{ $feat->category->color }};text-transform:uppercase">
                                {{ $feat->category->name }}
                            </span>
                            @endif
                            <h4 style="font-family:var(--serif);font-size:0.95rem;color:white;margin:0.25rem 0;line-height:1.3">
                                {{ Str::limit($feat->title, 50) }}
                            </h4>
                            <small style="font-family:var(--mono);font-size:0.7rem;color:rgba(255,255,255,0.5)">
                                {{ $feat->reading_time }} min
                            </small>
                        </div>
                    </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</section>
@endif

{{-- MAIN CONTENT --}}
<div class="container py-5">
    <div class="row g-4">
        {{-- ARTICLES --}}
        <div class="col-lg-8">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h2 style="font-family:var(--serif);font-size:1.5rem;margin:0">
                    <i class="bi bi-newspaper me-2" style="color:var(--accent)"></i>Derniers articles
                </h2>
                <span class="post-meta">{{ $posts->total() }} article{{ $posts->total() > 1 ? 's' : '' }}</span>
            </div>

            <div class="row g-4">
                @forelse($posts as $post)
                <div class="col-md-6">
                    <article class="post-card">
                        @if($post->cover_image)
                            <img src="{{ asset('storage/'.$post->cover_image) }}"
                                 class="card-img-top" alt="{{ $post->title }}">
                        @else
                            <div class="card-img-placeholder">
                                <i class="bi bi-journal-text"></i>
                            </div>
                        @endif

                        <div class="card-body">
                            @if($post->category)
                                <a href="{{ route('blog.category', $post->category->slug) }}"
                                   class="badge-category d-inline-block mb-2"
                                   style="background:{{ $post->category->color }};color:white;text-decoration:none">
                                    {{ $post->category->name }}
                                </a>
                            @endif

                            <h3 class="card-title">
                                <a href="{{ route('blog.show', $post->slug) }}">{{ $post->title }}</a>
                            </h3>

                            @if($post->excerpt)
                                <p class="text-muted" style="font-size:0.9rem;line-height:1.6">
                                    {{ Str::limit($post->excerpt, 100) }}
                                </p>
                            @endif
                        </div>

                        <div class="card-footer">
                            <div class="post-meta d-flex align-items-center justify-content-between">
                                <span><i class="bi bi-person me-1"></i>{{ $post->author->name }}</span>
                                <div class="d-flex gap-2">
                                    <span><i class="bi bi-chat me-1"></i>{{ $post->approvedComments->count() }}</span>
                                    <span><i class="bi bi-clock me-1"></i>{{ $post->reading_time }}min</span>
                                </div>
                            </div>
                            <div class="mt-2 d-flex align-items-center justify-content-between">
                                <small class="post-meta">{{ $post->published_at?->format('d M Y') }}</small>
                                <a href="{{ route('blog.show', $post->slug) }}" class="btn-ink"
                                   style="text-decoration:none;font-size:0.7rem;padding:0.35rem 0.8rem">
                                    Lire <i class="bi bi-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                </div>
                @empty
                <div class="col-12">
                    <div class="text-center py-5" style="background:white;border:1.5px dashed var(--border)">
                        <i class="bi bi-journal-x display-3 text-muted"></i>
                        <p class="mt-3 text-muted">Aucun article pour le moment.</p>
                    </div>
                </div>
                @endforelse
            </div>

            {{-- PAGINATION --}}
            @if($posts->hasPages())
            <div class="d-flex justify-content-center mt-4">
                {{ $posts->links() }}
            </div>
            @endif
        </div>

        {{-- SIDEBAR --}}
        <div class="col-lg-4">
            @include('blog.partials.sidebar', ['categories' => $categories, 'recentPosts' => $recentPosts])
        </div>
    </div>
</div>

@endsection
