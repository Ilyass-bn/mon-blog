<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Admin') | MonBlog Admin</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <style>
        :root {
            --ink: #1a1a2e;
            --ink-light: #2d2d44;
            --warm-white: #faf9f7;
            --accent: #e63946;
            --accent-hover: #d62839;
            --border: #e5e5e5;
            --text-muted: #6b7280;
            --success: #10b981;
            --warning: #f59e0b;
            --sans: 'Inter', -apple-system, sans-serif;
            --mono: 'JetBrains Mono', monospace;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--sans);
            background: #f3f4f6;
            color: var(--ink);
            line-height: 1.5;
        }

        /* ─── SIDEBAR ─── */
        .admin-sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 260px;
            height: 100vh;
            background: var(--ink);
            padding: 1.5rem;
            overflow-y: auto;
            z-index: 1000;
        }

        .admin-sidebar .brand {
            font-size: 1.3rem;
            font-weight: 700;
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .admin-sidebar .nav-section {
            font-family: var(--mono);
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: rgba(255,255,255,0.4);
            margin: 1.5rem 0 0.75rem;
        }

        .admin-sidebar .nav-link {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            font-size: 0.9rem;
            border-radius: 6px;
            transition: all 0.2s;
            margin-bottom: 0.25rem;
        }

        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .admin-sidebar .nav-link.active {
            background: var(--accent);
            color: white;
        }

        .admin-sidebar .nav-link i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }

        /* ─── MAIN CONTENT ─── */
        .admin-main {
            margin-left: 260px;
            min-height: 100vh;
        }

        .admin-header {
            background: white;
            padding: 1rem 2rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .admin-header h1 {
            font-size: 1.25rem;
            font-weight: 600;
            margin: 0;
        }

        .admin-content {
            padding: 2rem;
        }

        /* ─── CARDS ─── */
        .stat-card {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            border: 1px solid var(--border);
        }

        .stat-card .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
        }

        .stat-card .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            margin: 0.5rem 0 0.25rem;
        }

        .stat-card .stat-label {
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        /* ─── TABLES ─── */
        .admin-table {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid var(--border);
        }

        .admin-table table {
            margin: 0;
        }

        .admin-table th {
            background: var(--warm-white);
            font-family: var(--mono);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
            color: var(--text-muted);
            border-bottom: 1px solid var(--border);
        }

        .admin-table td {
            vertical-align: middle;
            font-size: 0.9rem;
        }

        /* ─── BUTTONS ─── */
        .btn-admin {
            font-family: var(--mono);
            font-size: 0.8rem;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            border: none;
            transition: all 0.2s;
        }

        .btn-admin-primary {
            background: var(--ink);
            color: white;
        }

        .btn-admin-primary:hover {
            background: var(--ink-light);
            color: white;
        }

        .btn-admin-accent {
            background: var(--accent);
            color: white;
        }

        .btn-admin-accent:hover {
            background: var(--accent-hover);
            color: white;
        }

        .btn-admin-outline {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--ink);
        }

        .btn-admin-outline:hover {
            background: var(--warm-white);
        }

        /* ─── BADGES ─── */
        .badge-status {
            font-family: var(--mono);
            font-size: 0.7rem;
            padding: 0.35rem 0.6rem;
            border-radius: 4px;
            text-transform: uppercase;
        }

        .badge-published {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-draft {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-pending {
            background: #fee2e2;
            color: #991b1b;
        }

        .badge-approved {
            background: #d1fae5;
            color: #065f46;
        }

        /* ─── FORMS ─── */
        .form-control, .form-select {
            border-radius: 6px;
            border: 1px solid var(--border);
            font-size: 0.9rem;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--ink);
            box-shadow: 0 0 0 3px rgba(26,26,46,0.1);
        }

        .form-label {
            font-family: var(--mono);
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.5rem;
            color: var(--text-muted);
        }

        /* ─── ALERTS ─── */
        .alert {
            border-radius: 6px;
            border: none;
            font-size: 0.9rem;
        }

        /* ─── RESPONSIVE ─── */
        @media (max-width: 991px) {
            .admin-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .admin-sidebar.show {
                transform: translateX(0);
            }

            .admin-main {
                margin-left: 0;
            }
        }
    </style>

    @stack('styles')
</head>
<body>
    <!-- SIDEBAR -->
    <aside class="admin-sidebar">
        <a href="{{ route('admin.dashboard') }}" class="brand">
            <i class="bi bi-journal-bookmark-fill" style="color:var(--accent)"></i>
            MonBlog
        </a>

        <nav>
            <div class="nav-section">Principal</div>
            <a href="{{ route('admin.dashboard') }}" class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <i class="bi bi-speedometer2"></i>
                Tableau de bord
            </a>

            <div class="nav-section">Contenu</div>
            <a href="{{ route('admin.posts.index') }}" class="nav-link {{ request()->routeIs('admin.posts.*') ? 'active' : '' }}">
                <i class="bi bi-file-text"></i>
                Articles
            </a>
            <a href="{{ route('admin.categories.index') }}" class="nav-link {{ request()->routeIs('admin.categories.*') ? 'active' : '' }}">
                <i class="bi bi-folder"></i>
                Catégories
            </a>
            <a href="{{ route('admin.comments.index') }}" class="nav-link {{ request()->routeIs('admin.comments.*') ? 'active' : '' }}">
                <i class="bi bi-chat-dots"></i>
                Commentaires
            </a>

            <div class="nav-section">Actions</div>
            <a href="{{ route('home') }}" class="nav-link" target="_blank">
                <i class="bi bi-box-arrow-up-right"></i>
                Voir le site
            </a>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="nav-link w-100 text-start border-0 bg-transparent">
                    <i class="bi bi-box-arrow-left"></i>
                    Déconnexion
                </button>
            </form>
        </nav>
    </aside>

    <!-- MAIN -->
    <main class="admin-main">
        <header class="admin-header">
            <h1>@yield('header', 'Administration')</h1>
            <div class="d-flex align-items-center gap-3">
                <span style="font-size:0.85rem;color:var(--text-muted)">
                    <i class="bi bi-person-circle me-1"></i>{{ auth()->user()->name }}
                </span>
            </div>
        </header>

        <div class="admin-content">
            {{-- Flash Messages --}}
            @if(session('success'))
            <div class="alert alert-success mb-4" style="background:#d1fae5;color:#065f46">
                <i class="bi bi-check-circle me-2"></i>{{ session('success') }}
            </div>
            @endif

            @if(session('error'))
            <div class="alert alert-danger mb-4" style="background:#fee2e2;color:#991b1b">
                <i class="bi bi-exclamation-circle me-2"></i>{{ session('error') }}
            </div>
            @endif

            @yield('content')
        </div>
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
