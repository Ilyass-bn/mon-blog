<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="@yield('description', 'MonBlog - Un blog moderne avec Laravel et Bootstrap')">
    <title>@yield('title', 'MonBlog') | MonBlog</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <style>
        :root {
            --ink: #1a1a2e;
            --ink-light: #2d2d44;
            --warm-white: #faf9f7;
            --accent: #e63946;
            --accent-hover: #d62839;
            --border: #e5e5e5;
            --text-muted: #6b7280;
            --serif: 'Playfair Display', Georgia, serif;
            --sans: 'Inter', -apple-system, sans-serif;
            --mono: 'JetBrains Mono', monospace;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: var(--sans);
            background: var(--warm-white);
            color: var(--ink);
            line-height: 1.6;
        }

        /* ─── NAVBAR ─── */
        .navbar-custom {
            background: var(--ink);
            padding: 1rem 0;
            border-bottom: 3px solid var(--accent);
        }

        .navbar-brand {
            font-family: var(--serif);
            font-size: 1.5rem;
            font-weight: 700;
            color: white !important;
            letter-spacing: -0.5px;
        }

        .navbar-nav .nav-link {
            font-family: var(--mono);
            font-size: 0.8rem;
            color: rgba(255,255,255,0.7) !important;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.5rem 1rem !important;
            transition: color 0.2s;
        }

        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: white !important;
        }

        /* ─── CARDS ─── */
        .post-card {
            background: white;
            border: 1.5px solid var(--border);
            border-radius: 0;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .post-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }

        .post-card .card-img-top {
            height: 200px;
            object-fit: cover;
            border-bottom: 1.5px solid var(--border);
        }

        .post-card .card-img-placeholder {
            height: 200px;
            background: linear-gradient(135deg, var(--ink) 0%, var(--ink-light) 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgba(255,255,255,0.3);
            font-size: 3rem;
            border-bottom: 1.5px solid var(--border);
        }

        .post-card .card-body {
            padding: 1.25rem;
            flex-grow: 1;
        }

        .post-card .card-title {
            font-family: var(--serif);
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 0.75rem;
            line-height: 1.3;
        }

        .post-card .card-title a {
            color: var(--ink);
            text-decoration: none;
            transition: color 0.2s;
        }

        .post-card .card-title a:hover {
            color: var(--accent);
        }

        .post-card .card-footer {
            background: var(--warm-white);
            border-top: 1.5px solid var(--border);
            padding: 1rem 1.25rem;
        }

        /* ─── BADGES ─── */
        .badge-category {
            font-family: var(--mono);
            font-size: 0.65rem;
            font-weight: 500;
            padding: 0.35rem 0.6rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-radius: 0;
        }

        /* ─── BUTTONS ─── */
        .btn-ink {
            background: var(--ink);
            color: white;
            border: none;
            border-radius: 0;
            font-family: var(--mono);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.6rem 1.2rem;
            transition: background 0.2s;
        }

        .btn-ink:hover {
            background: var(--ink-light);
            color: white;
        }

        .btn-accent {
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 0;
            font-family: var(--mono);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.6rem 1.2rem;
            transition: background 0.2s;
        }

        .btn-accent:hover {
            background: var(--accent-hover);
            color: white;
        }

        /* ─── POST META ─── */
        .post-meta {
            font-family: var(--mono);
            font-size: 0.72rem;
            color: var(--text-muted);
        }

        /* ─── SIDEBAR ─── */
        .sidebar-widget {
            background: white;
            border: 1.5px solid var(--border);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .sidebar-widget h4 {
            font-family: var(--serif);
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 2px solid var(--ink);
        }

        /* ─── FOOTER ─── */
        .footer {
            background: var(--ink);
            color: rgba(255,255,255,0.7);
            padding: 3rem 0 2rem;
            margin-top: 4rem;
        }

        .footer a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: color 0.2s;
        }

        .footer a:hover {
            color: white;
        }

        /* ─── FEATURED HERO ─── */
        .featured-hero {
            position: relative;
            height: 400px;
            background-size: cover;
            background-position: center;
            display: flex;
            align-items: flex-end;
        }

        .featured-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
        }

        .featured-hero-content {
            position: relative;
            z-index: 1;
            padding: 2rem;
            color: white;
            width: 100%;
        }

        /* ─── ALERTS ─── */
        .alert {
            border-radius: 0;
            border: none;
            font-family: var(--mono);
            font-size: 0.85rem;
        }

        /* ─── FORMS ─── */
        .form-control, .form-select {
            border-radius: 0;
            border: 1.5px solid var(--border);
            font-size: 0.9rem;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--ink);
            box-shadow: none;
        }

        /* ─── PAGINATION ─── */
        .pagination .page-link {
            border-radius: 0;
            color: var(--ink);
            border: 1.5px solid var(--border);
            font-family: var(--mono);
            font-size: 0.8rem;
        }

        .pagination .page-item.active .page-link {
            background: var(--ink);
            border-color: var(--ink);
        }
    </style>

    @stack('styles')
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
            <a class="navbar-brand" href="{{ route('home') }}">
                <i class="bi bi-journal-bookmark-fill me-2"></i>MonBlog
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">
                            <i class="bi bi-house me-1"></i>Accueil
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('blog.search') }}">
                            <i class="bi bi-search me-1"></i>Recherche
                        </a>
                    </li>
                    @auth
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('admin.dashboard') }}">
                                <i class="bi bi-speedometer2 me-1"></i>Admin
                            </a>
                        </li>
                        <li class="nav-item">
                            <form action="{{ route('logout') }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="nav-link border-0 bg-transparent">
                                    <i class="bi bi-box-arrow-right me-1"></i>Déconnexion
                                </button>
                            </form>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">
                                <i class="bi bi-person me-1"></i>Admin
                            </a>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <!-- MAIN CONTENT -->
    <main>
        @yield('content')
    </main>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5 style="font-family:var(--serif);color:white;margin-bottom:1rem">MonBlog</h5>
                    <p style="font-size:0.9rem;max-width:400px">
                        Un blog moderne construit avec Laravel et Bootstrap.
                        Partagez vos idées et découvrez du contenu inspirant.
                    </p>
                </div>
                <div class="col-md-3">
                    <h6 style="font-family:var(--mono);font-size:0.75rem;text-transform:uppercase;color:white;margin-bottom:1rem">
                        Navigation
                    </h6>
                    <ul class="list-unstyled" style="font-size:0.9rem">
                        <li class="mb-2"><a href="{{ route('home') }}">Accueil</a></li>
                        <li class="mb-2"><a href="{{ route('blog.search') }}">Recherche</a></li>
                        <li class="mb-2"><a href="{{ route('login') }}">Administration</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h6 style="font-family:var(--mono);font-size:0.75rem;text-transform:uppercase;color:white;margin-bottom:1rem">
                        Contact
                    </h6>
                    <p style="font-size:0.9rem">
                        <i class="bi bi-envelope me-2"></i>contact@monblog.com
                    </p>
                </div>
            </div>
            <hr style="border-color:rgba(255,255,255,0.1);margin:2rem 0 1rem">
            <p class="text-center mb-0" style="font-family:var(--mono);font-size:0.75rem;color:rgba(255,255,255,0.5)">
                &copy; {{ date('Y') }} MonBlog. Tous droits réservés.
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
