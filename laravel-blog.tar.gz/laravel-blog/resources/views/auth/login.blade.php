@extends('layouts.app')

@section('title', 'Connexion')

@section('content')

<div style="min-height:80vh;display:flex;align-items:center;justify-content:center;background:var(--warm-white)">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div style="background:white;border:1.5px solid var(--border);padding:2.5rem">
                    {{-- Logo --}}
                    <div class="text-center mb-4">
                        <a href="{{ route('home') }}" style="font-family:var(--serif);font-size:1.8rem;color:var(--ink);text-decoration:none">
                            <i class="bi bi-journal-bookmark-fill me-2" style="color:var(--accent)"></i>MonBlog
                        </a>
                        <p class="text-muted mt-2" style="font-family:var(--mono);font-size:0.8rem">
                            Espace Administration
                        </p>
                    </div>

                    {{-- Errors --}}
                    @if($errors->any())
                    <div class="alert alert-danger mb-4" style="background:#fee2e2;border:1px solid #fecaca;color:#991b1b">
                        <i class="bi bi-exclamation-circle me-2"></i>
                        {{ $errors->first() }}
                    </div>
                    @endif

                    {{-- Form --}}
                    <form action="{{ route('login.post') }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label" style="font-family:var(--mono);font-size:0.8rem;text-transform:uppercase">
                                Adresse email
                            </label>
                            <input type="email" name="email"
                                   class="form-control @error('email') is-invalid @enderror"
                                   value="{{ old('email') }}"
                                   placeholder="admin@blog.com"
                                   required autofocus>
                        </div>

                        <div class="mb-3">
                            <label class="form-label" style="font-family:var(--mono);font-size:0.8rem;text-transform:uppercase">
                                Mot de passe
                            </label>
                            <input type="password" name="password"
                                   class="form-control @error('password') is-invalid @enderror"
                                   placeholder="••••••••"
                                   required>
                        </div>

                        <div class="mb-4">
                            <div class="form-check">
                                <input type="checkbox" name="remember" id="remember" class="form-check-input">
                                <label for="remember" class="form-check-label" style="font-size:0.9rem">
                                    Se souvenir de moi
                                </label>
                            </div>
                        </div>

                        <button type="submit" class="btn-accent w-100 py-2">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Se connecter
                        </button>
                    </form>

                    <div class="text-center mt-4 pt-4" style="border-top:1px solid var(--border)">
                        <a href="{{ route('home') }}" class="text-muted" style="font-size:0.85rem">
                            <i class="bi bi-arrow-left me-1"></i>Retour au blog
                        </a>
                    </div>
                </div>

                {{-- Demo credentials --}}
                <div class="text-center mt-3">
                    <small class="text-muted" style="font-family:var(--mono);font-size:0.75rem">
                        Demo: admin@blog.com / password
                    </small>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
