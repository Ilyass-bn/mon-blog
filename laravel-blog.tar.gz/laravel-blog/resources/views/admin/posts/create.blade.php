@extends('layouts.admin')

@section('title', isset($post) ? 'Modifier l\'article' : 'Nouvel article')
@section('header', isset($post) ? 'Modifier l\'article' : 'Nouvel article')

@section('content')

<form action="{{ isset($post) ? route('admin.posts.update', $post) : route('admin.posts.store') }}"
      method="POST" enctype="multipart/form-data">
    @csrf
    @if(isset($post))
        @method('PUT')
    @endif

    <div class="row g-4">
        {{-- MAIN CONTENT --}}
        <div class="col-lg-8">
            <div style="background:white;border-radius:8px;border:1px solid var(--border);padding:1.5rem">
                {{-- Title --}}
                <div class="mb-4">
                    <label class="form-label">Titre *</label>
                    <input type="text" name="title"
                           class="form-control @error('title') is-invalid @enderror"
                           value="{{ old('title', $post->title ?? '') }}"
                           placeholder="Titre de l'article" required>
                    @error('title')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Excerpt --}}
                <div class="mb-4">
                    <label class="form-label">Extrait</label>
                    <textarea name="excerpt" rows="2"
                              class="form-control @error('excerpt') is-invalid @enderror"
                              placeholder="Résumé court de l'article (optionnel)">{{ old('excerpt', $post->excerpt ?? '') }}</textarea>
                    @error('excerpt')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    <small class="text-muted">Max 500 caractères</small>
                </div>

                {{-- Content --}}
                <div class="mb-0">
                    <label class="form-label">Contenu *</label>
                    <textarea name="content" rows="15"
                              class="form-control @error('content') is-invalid @enderror"
                              placeholder="Rédigez votre article ici... (HTML autorisé)"
                              required>{{ old('content', $post->content ?? '') }}</textarea>
                    @error('content')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    <small class="text-muted">Vous pouvez utiliser du HTML pour la mise en forme.</small>
                </div>
            </div>
        </div>

        {{-- SIDEBAR --}}
        <div class="col-lg-4">
            {{-- Publish Box --}}
            <div style="background:white;border-radius:8px;border:1px solid var(--border);padding:1.5rem;margin-bottom:1rem">
                <h5 style="font-size:1rem;font-weight:600;margin-bottom:1rem">
                    <i class="bi bi-gear me-2"></i>Publication
                </h5>

                {{-- Status --}}
                <div class="mb-3">
                    <label class="form-label">Statut *</label>
                    <select name="status" class="form-select @error('status') is-invalid @enderror">
                        <option value="draft" {{ old('status', $post->status ?? 'draft') === 'draft' ? 'selected' : '' }}>
                            Brouillon
                        </option>
                        <option value="published" {{ old('status', $post->status ?? '') === 'published' ? 'selected' : '' }}>
                            Publié
                        </option>
                    </select>
                </div>

                {{-- Featured --}}
                <div class="mb-3">
                    <div class="form-check">
                        <input type="hidden" name="featured" value="0">
                        <input type="checkbox" name="featured" value="1"
                               class="form-check-input" id="featured"
                               {{ old('featured', $post->featured ?? false) ? 'checked' : '' }}>
                        <label class="form-check-label" for="featured">
                            <i class="bi bi-star me-1" style="color:var(--warning)"></i>
                            Mettre à la une
                        </label>
                    </div>
                </div>

                <hr>

                {{-- Actions --}}
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-admin btn-admin-accent">
                        <i class="bi bi-check-lg me-1"></i>
                        {{ isset($post) ? 'Mettre à jour' : 'Créer l\'article' }}
                    </button>
                    <a href="{{ route('admin.posts.index') }}" class="btn btn-admin btn-admin-outline">
                        Annuler
                    </a>
                </div>
            </div>

            {{-- Category --}}
            <div style="background:white;border-radius:8px;border:1px solid var(--border);padding:1.5rem;margin-bottom:1rem">
                <h5 style="font-size:1rem;font-weight:600;margin-bottom:1rem">
                    <i class="bi bi-folder me-2"></i>Catégorie
                </h5>

                <select name="category_id" class="form-select @error('category_id') is-invalid @enderror">
                    <option value="">Aucune catégorie</option>
                    @foreach($categories as $cat)
                    <option value="{{ $cat->id }}"
                            {{ old('category_id', $post->category_id ?? '') == $cat->id ? 'selected' : '' }}>
                        {{ $cat->name }}
                    </option>
                    @endforeach
                </select>
                @error('category_id')
                <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            {{-- Cover Image --}}
            <div style="background:white;border-radius:8px;border:1px solid var(--border);padding:1.5rem">
                <h5 style="font-size:1rem;font-weight:600;margin-bottom:1rem">
                    <i class="bi bi-image me-2"></i>Image de couverture
                </h5>

                @if(isset($post) && $post->cover_image)
                <div class="mb-3">
                    <img src="{{ asset('storage/'.$post->cover_image) }}"
                         class="img-fluid rounded" alt="Cover">
                    <small class="text-muted d-block mt-2">Image actuelle</small>
                </div>
                @endif

                <input type="file" name="cover_image"
                       class="form-control @error('cover_image') is-invalid @enderror"
                       accept="image/*">
                @error('cover_image')
                <div class="invalid-feedback">{{ $message }}</div>
                @enderror
                <small class="text-muted">JPG, PNG. Max 2 Mo</small>
            </div>
        </div>
    </div>
</form>

@endsection
