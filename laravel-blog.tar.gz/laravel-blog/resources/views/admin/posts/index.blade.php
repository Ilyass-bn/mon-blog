@extends('layouts.admin')

@section('title', 'Articles')
@section('header', 'Gestion des articles')

@section('content')

{{-- FILTERS & ACTIONS --}}
<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4">
    <form action="{{ route('admin.posts.index') }}" method="GET" class="d-flex gap-2 flex-wrap">
        <input type="text" name="search" class="form-control" placeholder="Rechercher..."
               value="{{ request('search') }}" style="width:200px">

        <select name="status" class="form-select" style="width:150px" onchange="this.form.submit()">
            <option value="">Tous les statuts</option>
            <option value="published" {{ request('status') === 'published' ? 'selected' : '' }}>Publiés</option>
            <option value="draft" {{ request('status') === 'draft' ? 'selected' : '' }}>Brouillons</option>
        </select>

        <select name="category" class="form-select" style="width:180px" onchange="this.form.submit()">
            <option value="">Toutes catégories</option>
            @foreach($categories as $cat)
            <option value="{{ $cat->id }}" {{ request('category') == $cat->id ? 'selected' : '' }}>
                {{ $cat->name }}
            </option>
            @endforeach
        </select>

        <button type="submit" class="btn btn-admin btn-admin-primary">
            <i class="bi bi-search"></i>
        </button>
    </form>

    <a href="{{ route('admin.posts.create') }}" class="btn btn-admin btn-admin-accent">
        <i class="bi bi-plus me-1"></i>Nouvel article
    </a>
</div>

{{-- POSTS TABLE --}}
<div class="admin-table">
    <table class="table table-hover mb-0">
        <thead>
            <tr>
                <th style="width:35%">Titre</th>
                <th>Catégorie</th>
                <th>Auteur</th>
                <th>Statut</th>
                <th class="text-center">Vues</th>
                <th class="text-center">Commentaires</th>
                <th>Date</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($posts as $post)
            <tr>
                <td>
                    <div class="d-flex align-items-center gap-3">
                        @if($post->cover_image)
                        <img src="{{ asset('storage/'.$post->cover_image) }}"
                             style="width:48px;height:48px;object-fit:cover;border-radius:4px"
                             alt="">
                        @else
                        <div style="width:48px;height:48px;background:var(--warm-white);border-radius:4px;display:flex;align-items:center;justify-content:center">
                            <i class="bi bi-image text-muted"></i>
                        </div>
                        @endif
                        <div>
                            <a href="{{ route('admin.posts.edit', $post) }}"
                               class="text-decoration-none d-block"
                               style="color:var(--ink);font-weight:500">
                                {{ Str::limit($post->title, 40) }}
                            </a>
                            @if($post->featured)
                            <small style="color:var(--warning)">
                                <i class="bi bi-star-fill me-1"></i>À la une
                            </small>
                            @endif
                        </div>
                    </div>
                </td>
                <td>
                    @if($post->category)
                    <span style="display:inline-flex;align-items:center;gap:0.5rem">
                        <span style="width:8px;height:8px;background:{{ $post->category->color }};border-radius:50%"></span>
                        {{ $post->category->name }}
                    </span>
                    @else
                    <span class="text-muted">—</span>
                    @endif
                </td>
                <td style="font-size:0.85rem">{{ $post->author->name }}</td>
                <td>
                    <span class="badge-status {{ $post->status === 'published' ? 'badge-published' : 'badge-draft' }}">
                        {{ $post->status === 'published' ? 'Publié' : 'Brouillon' }}
                    </span>
                </td>
                <td class="text-center" style="font-family:var(--mono);font-size:0.85rem">
                    {{ number_format($post->views) }}
                </td>
                <td class="text-center" style="font-family:var(--mono);font-size:0.85rem">
                    {{ $post->comments_count }}
                </td>
                <td style="font-family:var(--mono);font-size:0.8rem;color:var(--text-muted)">
                    {{ $post->created_at->format('d/m/Y') }}
                </td>
                <td class="text-end">
                    <div class="d-flex gap-1 justify-content-end">
                        {{-- Toggle status --}}
                        <form action="{{ route('admin.posts.toggle', $post) }}" method="POST" class="d-inline">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-admin-outline"
                                    title="{{ $post->status === 'published' ? 'Passer en brouillon' : 'Publier' }}">
                                <i class="bi {{ $post->status === 'published' ? 'bi-eye-slash' : 'bi-eye' }}"></i>
                            </button>
                        </form>

                        {{-- Edit --}}
                        <a href="{{ route('admin.posts.edit', $post) }}" class="btn btn-sm btn-admin-outline">
                            <i class="bi bi-pencil"></i>
                        </a>

                        {{-- View --}}
                        @if($post->status === 'published')
                        <a href="{{ route('blog.show', $post->slug) }}" target="_blank" class="btn btn-sm btn-admin-outline">
                            <i class="bi bi-box-arrow-up-right"></i>
                        </a>
                        @endif

                        {{-- Delete --}}
                        <form action="{{ route('admin.posts.destroy', $post) }}" method="POST" class="d-inline"
                              onsubmit="return confirm('Supprimer cet article ?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-admin-outline" style="color:var(--accent)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="text-center py-5">
                    <i class="bi bi-file-text display-4 text-muted"></i>
                    <p class="text-muted mt-2 mb-0">Aucun article trouvé</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- PAGINATION --}}
@if($posts->hasPages())
<div class="d-flex justify-content-center mt-4">
    {{ $posts->links() }}
</div>
@endif

@endsection
