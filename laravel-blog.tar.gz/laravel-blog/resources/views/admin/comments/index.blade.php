@extends('layouts.admin')

@section('title', 'Commentaires')
@section('header', 'Modération des commentaires')

@section('content')

{{-- FILTERS --}}
<div class="d-flex gap-2 mb-4">
    <a href="{{ route('admin.comments.index') }}"
       class="btn btn-admin {{ !request('status') ? 'btn-admin-primary' : 'btn-admin-outline' }}">
        Tous
    </a>
    <a href="{{ route('admin.comments.index', ['status' => 'pending']) }}"
       class="btn btn-admin {{ request('status') === 'pending' ? 'btn-admin-primary' : 'btn-admin-outline' }}">
        En attente
    </a>
    <a href="{{ route('admin.comments.index', ['status' => 'approved']) }}"
       class="btn btn-admin {{ request('status') === 'approved' ? 'btn-admin-primary' : 'btn-admin-outline' }}">
        Approuvés
    </a>
</div>

{{-- COMMENTS TABLE --}}
<div class="admin-table">
    <table class="table table-hover mb-0">
        <thead>
            <tr>
                <th style="width:20%">Auteur</th>
                <th style="width:35%">Commentaire</th>
                <th>Article</th>
                <th>Statut</th>
                <th>Date</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($comments as $comment)
            <tr>
                <td>
                    <div class="d-flex align-items-center gap-2">
                        <div style="width:36px;height:36px;background:var(--ink);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <span style="color:white;font-size:0.8rem;font-weight:600">
                                {{ strtoupper(substr($comment->author_name, 0, 1)) }}
                            </span>
                        </div>
                        <div>
                            <div style="font-weight:500;font-size:0.9rem">{{ $comment->author_name }}</div>
                            <small style="color:var(--text-muted);font-size:0.75rem">{{ $comment->author_email }}</small>
                        </div>
                    </div>
                </td>
                <td style="font-size:0.9rem">
                    {{ Str::limit($comment->content, 80) }}
                </td>
                <td>
                    @if($comment->post)
                    <a href="{{ route('admin.posts.edit', $comment->post) }}"
                       class="text-decoration-none" style="color:var(--ink);font-size:0.85rem">
                        {{ Str::limit($comment->post->title, 30) }}
                    </a>
                    @else
                    <span class="text-muted">Article supprimé</span>
                    @endif
                </td>
                <td>
                    <span class="badge-status {{ $comment->approved ? 'badge-approved' : 'badge-pending' }}">
                        {{ $comment->approved ? 'Approuvé' : 'En attente' }}
                    </span>
                </td>
                <td style="font-family:var(--mono);font-size:0.8rem;color:var(--text-muted)">
                    {{ $comment->created_at->format('d/m/Y H:i') }}
                </td>
                <td class="text-end">
                    <div class="d-flex gap-1 justify-content-end">
                        {{-- Toggle approval --}}
                        <form action="{{ route('admin.comments.approve', $comment) }}" method="POST" class="d-inline">
                            @csrf
                            <button type="submit" class="btn btn-sm btn-admin-outline"
                                    title="{{ $comment->approved ? 'Désapprouver' : 'Approuver' }}">
                                <i class="bi {{ $comment->approved ? 'bi-x-circle' : 'bi-check-circle' }}"
                                   style="color:{{ $comment->approved ? 'var(--accent)' : 'var(--success)' }}"></i>
                            </button>
                        </form>

                        {{-- Delete --}}
                        <form action="{{ route('admin.comments.destroy', $comment) }}" method="POST" class="d-inline"
                              onsubmit="return confirm('Supprimer ce commentaire ?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-admin-outline" style="color:var(--accent)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-center py-5">
                    <i class="bi bi-chat-dots display-4 text-muted"></i>
                    <p class="text-muted mt-2 mb-0">Aucun commentaire trouvé</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- PAGINATION --}}
@if($comments->hasPages())
<div class="d-flex justify-content-center mt-4">
    {{ $comments->links() }}
</div>
@endif

@endsection
