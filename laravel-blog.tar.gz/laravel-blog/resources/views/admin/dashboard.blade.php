@extends('layouts.admin')

@section('title', 'Tableau de bord')
@section('header', 'Tableau de bord')

@section('content')

{{-- STATS --}}
<div class="row g-4 mb-4">
    <div class="col-sm-6 col-lg-3">
        <div class="stat-card">
            <div class="d-flex align-items-start justify-content-between">
                <div>
                    <div class="stat-value">{{ $stats['total_posts'] }}</div>
                    <div class="stat-label">Articles total</div>
                </div>
                <div class="stat-icon" style="background:#dbeafe;color:#2563eb">
                    <i class="bi bi-file-text"></i>
                </div>
            </div>
            <div class="mt-3 pt-3 border-top" style="font-size:0.8rem">
                <span style="color:var(--success)">{{ $stats['published_posts'] }} publiés</span>
                <span class="text-muted mx-1">•</span>
                <span style="color:var(--warning)">{{ $stats['draft_posts'] }} brouillons</span>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="stat-card">
            <div class="d-flex align-items-start justify-content-between">
                <div>
                    <div class="stat-value">{{ $stats['total_comments'] }}</div>
                    <div class="stat-label">Commentaires</div>
                </div>
                <div class="stat-icon" style="background:#fef3c7;color:#d97706">
                    <i class="bi bi-chat-dots"></i>
                </div>
            </div>
            <div class="mt-3 pt-3 border-top" style="font-size:0.8rem">
                @if($stats['pending_comments'] > 0)
                <span style="color:var(--accent)">{{ $stats['pending_comments'] }} en attente</span>
                @else
                <span class="text-muted">Tous modérés</span>
                @endif
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="stat-card">
            <div class="d-flex align-items-start justify-content-between">
                <div>
                    <div class="stat-value">{{ $stats['total_categories'] }}</div>
                    <div class="stat-label">Catégories</div>
                </div>
                <div class="stat-icon" style="background:#d1fae5;color:#059669">
                    <i class="bi bi-folder"></i>
                </div>
            </div>
            <div class="mt-3 pt-3 border-top" style="font-size:0.8rem">
                <a href="{{ route('admin.categories.create') }}" class="text-decoration-none">
                    <i class="bi bi-plus me-1"></i>Nouvelle catégorie
                </a>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="stat-card">
            <div class="d-flex align-items-start justify-content-between">
                <div>
                    <div class="stat-value">{{ number_format($stats['total_views']) }}</div>
                    <div class="stat-label">Vues totales</div>
                </div>
                <div class="stat-icon" style="background:#ede9fe;color:#7c3aed">
                    <i class="bi bi-eye"></i>
                </div>
            </div>
            <div class="mt-3 pt-3 border-top" style="font-size:0.8rem">
                <span class="text-muted">Sur tous les articles</span>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    {{-- TOP POSTS --}}
    <div class="col-lg-6">
        <div class="admin-table">
            <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
                <h5 class="mb-0" style="font-size:1rem;font-weight:600">
                    <i class="bi bi-trophy me-2" style="color:var(--warning)"></i>Articles populaires
                </h5>
            </div>
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th style="width:60%">Article</th>
                        <th class="text-end">Vues</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($topPosts as $post)
                    <tr>
                        <td>
                            <a href="{{ route('admin.posts.edit', $post) }}" class="text-decoration-none" style="color:var(--ink)">
                                {{ Str::limit($post->title, 40) }}
                            </a>
                        </td>
                        <td class="text-end">
                            <span style="font-family:var(--mono);font-size:0.85rem">
                                {{ number_format($post->views) }}
                            </span>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="2" class="text-center text-muted py-4">Aucun article</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- RECENT COMMENTS --}}
    <div class="col-lg-6">
        <div class="admin-table">
            <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
                <h5 class="mb-0" style="font-size:1rem;font-weight:600">
                    <i class="bi bi-chat-left-text me-2" style="color:var(--accent)"></i>Derniers commentaires
                </h5>
                <a href="{{ route('admin.comments.index') }}" class="btn btn-sm btn-admin-outline">
                    Voir tout
                </a>
            </div>
            <div class="p-3">
                @forelse($recentComments as $comment)
                <div class="d-flex gap-3 {{ !$loop->last ? 'mb-3 pb-3 border-bottom' : '' }}">
                    <div style="width:36px;height:36px;background:var(--ink);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                        <span style="color:white;font-size:0.8rem;font-weight:600">
                            {{ strtoupper(substr($comment->author_name, 0, 1)) }}
                        </span>
                    </div>
                    <div class="flex-grow-1 min-width-0">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <strong style="font-size:0.85rem">{{ $comment->author_name }}</strong>
                            <span class="badge-status {{ $comment->approved ? 'badge-approved' : 'badge-pending' }}">
                                {{ $comment->approved ? 'Approuvé' : 'En attente' }}
                            </span>
                        </div>
                        <p class="mb-1 text-muted" style="font-size:0.85rem">
                            {{ Str::limit($comment->content, 60) }}
                        </p>
                        <small style="font-family:var(--mono);font-size:0.7rem;color:var(--text-muted)">
                            sur {{ Str::limit($comment->post->title ?? 'Article supprimé', 25) }}
                        </small>
                    </div>
                </div>
                @empty
                <p class="text-center text-muted py-4 mb-0">Aucun commentaire</p>
                @endforelse
            </div>
        </div>
    </div>

    {{-- RECENT POSTS --}}
    <div class="col-12">
        <div class="admin-table">
            <div class="p-3 border-bottom d-flex align-items-center justify-content-between">
                <h5 class="mb-0" style="font-size:1rem;font-weight:600">
                    <i class="bi bi-clock-history me-2" style="color:var(--success)"></i>Derniers articles
                </h5>
                <a href="{{ route('admin.posts.create') }}" class="btn btn-admin btn-admin-accent">
                    <i class="bi bi-plus me-1"></i>Nouvel article
                </a>
            </div>
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Titre</th>
                        <th>Catégorie</th>
                        <th>Statut</th>
                        <th>Date</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($recentPosts as $post)
                    <tr>
                        <td>
                            <a href="{{ route('admin.posts.edit', $post) }}" class="text-decoration-none" style="color:var(--ink);font-weight:500">
                                {{ Str::limit($post->title, 50) }}
                            </a>
                        </td>
                        <td>
                            @if($post->category)
                            <span style="display:inline-flex;align-items:center;gap:0.5rem">
                                <span style="width:8px;height:8px;background:{{ $post->category->color }};border-radius:50%"></span>
                                {{ $post->category->name }}
                            </span>
                            @else
                            <span class="text-muted">—</span>
                            @endif
                        </td>
                        <td>
                            <span class="badge-status {{ $post->status === 'published' ? 'badge-published' : 'badge-draft' }}">
                                {{ $post->status === 'published' ? 'Publié' : 'Brouillon' }}
                            </span>
                        </td>
                        <td style="font-family:var(--mono);font-size:0.8rem;color:var(--text-muted)">
                            {{ $post->created_at->format('d/m/Y') }}
                        </td>
                        <td class="text-end">
                            <a href="{{ route('admin.posts.edit', $post) }}" class="btn btn-sm btn-admin-outline">
                                <i class="bi bi-pencil"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">Aucun article</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@endsection
