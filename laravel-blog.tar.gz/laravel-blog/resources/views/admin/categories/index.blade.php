@extends('layouts.admin')

@section('title', 'Catégories')
@section('header', 'Gestion des catégories')

@section('content')

<div class="d-flex justify-content-end mb-4">
    <a href="{{ route('admin.categories.create') }}" class="btn btn-admin btn-admin-accent">
        <i class="bi bi-plus me-1"></i>Nouvelle catégorie
    </a>
</div>

<div class="admin-table">
    <table class="table table-hover mb-0">
        <thead>
            <tr>
                <th>Couleur</th>
                <th>Nom</th>
                <th>Slug</th>
                <th>Description</th>
                <th class="text-center">Articles</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($categories as $category)
            <tr>
                <td>
                    <div style="width:24px;height:24px;background:{{ $category->color }};border-radius:4px"></div>
                </td>
                <td style="font-weight:500">{{ $category->name }}</td>
                <td style="font-family:var(--mono);font-size:0.85rem;color:var(--text-muted)">
                    {{ $category->slug }}
                </td>
                <td style="font-size:0.85rem;color:var(--text-muted)">
                    {{ Str::limit($category->description, 50) ?? '—' }}
                </td>
                <td class="text-center">
                    <span style="font-family:var(--mono);font-size:0.85rem">{{ $category->posts_count }}</span>
                </td>
                <td class="text-end">
                    <div class="d-flex gap-1 justify-content-end">
                        <a href="{{ route('admin.categories.edit', $category) }}" class="btn btn-sm btn-admin-outline">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="{{ route('blog.category', $category->slug) }}" target="_blank" class="btn btn-sm btn-admin-outline">
                            <i class="bi bi-box-arrow-up-right"></i>
                        </a>
                        <form action="{{ route('admin.categories.destroy', $category) }}" method="POST" class="d-inline"
                              onsubmit="return confirm('Supprimer cette catégorie ?')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-admin-outline" style="color:var(--accent)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-center py-5">
                    <i class="bi bi-folder display-4 text-muted"></i>
                    <p class="text-muted mt-2 mb-0">Aucune catégorie</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@endsection
