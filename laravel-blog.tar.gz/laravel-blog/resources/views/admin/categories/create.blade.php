@extends('layouts.admin')

@section('title', isset($category) ? 'Modifier la catégorie' : 'Nouvelle catégorie')
@section('header', isset($category) ? 'Modifier la catégorie' : 'Nouvelle catégorie')

@section('content')

<div class="row justify-content-center">
    <div class="col-lg-6">
        <div style="background:white;border-radius:8px;border:1px solid var(--border);padding:2rem">
            <form action="{{ isset($category) ? route('admin.categories.update', $category) : route('admin.categories.store') }}"
                  method="POST">
                @csrf
                @if(isset($category))
                    @method('PUT')
                @endif

                {{-- Name --}}
                <div class="mb-4">
                    <label class="form-label">Nom *</label>
                    <input type="text" name="name"
                           class="form-control @error('name') is-invalid @enderror"
                           value="{{ old('name', $category->name ?? '') }}"
                           placeholder="Nom de la catégorie" required>
                    @error('name')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Description --}}
                <div class="mb-4">
                    <label class="form-label">Description</label>
                    <textarea name="description" rows="3"
                              class="form-control @error('description') is-invalid @enderror"
                              placeholder="Description de la catégorie (optionnel)">{{ old('description', $category->description ?? '') }}</textarea>
                    @error('description')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Color --}}
                <div class="mb-4">
                    <label class="form-label">Couleur</label>
                    <div class="d-flex align-items-center gap-3">
                        <input type="color" name="color"
                               class="form-control form-control-color"
                               value="{{ old('color', $category->color ?? '#3b82f6') }}"
                               style="width:60px;height:40px">
                        <input type="text"
                               class="form-control"
                               value="{{ old('color', $category->color ?? '#3b82f6') }}"
                               style="width:100px;font-family:var(--mono);font-size:0.85rem"
                               readonly>
                    </div>
                    @error('color')
                    <div class="text-danger small mt-1">{{ $message }}</div>
                    @enderror
                </div>

                <hr class="my-4">

                {{-- Actions --}}
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-admin btn-admin-accent flex-grow-1">
                        <i class="bi bi-check-lg me-1"></i>
                        {{ isset($category) ? 'Mettre à jour' : 'Créer la catégorie' }}
                    </button>
                    <a href="{{ route('admin.categories.index') }}" class="btn btn-admin btn-admin-outline">
                        Annuler
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
    // Sync color picker with text input
    const colorInput = document.querySelector('input[type="color"]');
    const colorText = document.querySelector('input[readonly]');
    colorInput.addEventListener('input', (e) => {
        colorText.value = e.target.value;
    });
</script>
@endpush

@endsection
