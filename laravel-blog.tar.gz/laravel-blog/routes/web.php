<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\PostController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\CommentController;
use Illuminate\Support\Facades\Route;

/* ═══════════════════════════════════════════
   PUBLIC BLOG ROUTES
═══════════════════════════════════════════ */

// Home (featured + recent articles)
Route::get('/', [BlogController::class, 'index'])->name('home');

// Alias: /blog — same controller, different URL
Route::get('/blog', [BlogController::class, 'index'])->name('blog.index');

// Search
Route::get('/blog/search', [BlogController::class, 'search'])->name('blog.search');

// Category archive
Route::get('/blog/categorie/{slug}', [BlogController::class, 'category'])->name('blog.category');

// Single post
Route::get('/blog/{slug}', [BlogController::class, 'show'])->name('blog.show');

// Post comment
Route::post('/blog/{post}/commentaires', [BlogController::class, 'storeComment'])
    ->name('blog.comment.store');

/* ═══════════════════════════════════════════
   AUTHENTICATION
═══════════════════════════════════════════ */

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

/* ═══════════════════════════════════════════
   ADMIN — requires auth + is_admin
═══════════════════════════════════════════ */

Route::prefix('admin')
    ->name('admin.')
    ->middleware(['auth', 'admin'])
    ->group(function () {

        // Dashboard
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        // Posts
        Route::resource('posts', PostController::class);
        Route::post('posts/{post}/toggle', [PostController::class, 'toggle'])
            ->name('posts.toggle');

        // Categories
        Route::resource('categories', CategoryController::class);

        // Comments
        Route::get('commentaires', [CommentController::class, 'index'])
            ->name('comments.index');
        Route::post('commentaires/{comment}/approuver', [CommentController::class, 'approve'])
            ->name('comments.approve');
        Route::delete('commentaires/{comment}', [CommentController::class, 'destroy'])
            ->name('comments.destroy');
    });
