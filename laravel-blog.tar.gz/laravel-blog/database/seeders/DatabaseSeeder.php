<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Comment;
use App\Models\Post;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        /* ── Admin user ── */
        $admin = User::firstOrCreate(
            ['email' => 'admin@blog.com'],
            [
                'name'     => 'Administrateur',
                'password' => Hash::make('password'),
                'is_admin' => true,
            ]
        );

        /* ── Categories ── */
        $categoryData = [
            ['name' => 'Technologie',   'color' => '#3b82f6', 'description' => 'Actualites et tendances tech.'],
            ['name' => 'Design',        'color' => '#ec4899', 'description' => 'UI, UX et inspiration creative.'],
            ['name' => 'Developpement', 'color' => '#10b981', 'description' => 'Tutoriels et bonnes pratiques.'],
            ['name' => 'Actualites',    'color' => '#f59e0b', 'description' => 'Le monde en bref.'],
            ['name' => 'Open Source',   'color' => '#8b5cf6', 'description' => 'Projets et communautes libres.'],
        ];

        $categories = [];
        foreach ($categoryData as $data) {
            $data['slug'] = Str::slug($data['name']);
            $categories[] = Category::firstOrCreate(['slug' => $data['slug']], $data);
        }

        /* ── Sample posts ── */
        $posts = [
            [
                'title'    => 'Bienvenue sur MonBlog',
                'excerpt'  => "Decouvrez pourquoi nous avons lance ce blog et ce que vous pouvez attendre de notre contenu.",
                'content'  => "<p>Bienvenue ! Ce blog est ne d'une passion pour le partage de connaissances.</p><p>Nous couvrirons la technologie, le design et le developpement.</p>",
                'status'   => 'published',
                'featured' => true,
                'category' => $categories[0],
                'views'    => 1240,
            ],
            [
                'title'    => 'Les 10 meilleures pratiques CSS en 2024',
                'excerpt'  => "Un tour d'horizon des techniques CSS modernes pour ecrire du code maintenable.",
                'content'  => "<p>CSS a enormement evolue ces dernieres annees.</p><h2>1. Variables CSS</h2><p>Les proprietes personnalisees changent tout.</p>",
                'status'   => 'published',
                'featured' => true,
                'category' => $categories[1],
                'views'    => 856,
            ],
            [
                'title'    => 'Introduction a Laravel 11',
                'excerpt'  => "Laravel 11 simplifie encore la structure du projet. Faisons le point sur les nouveautes.",
                'content'  => "<p>Laravel 11 est sorti avec une nouvelle structure de dossiers minimaliste.</p><h2>bootstrap/app.php</h2><p>Le noyau HTTP est remplace par ce fichier.</p>",
                'status'   => 'published',
                'featured' => true,
                'category' => $categories[2],
                'views'    => 2031,
            ],
            [
                'title'    => 'Figma vs Adobe XD : quel outil choisir ?',
                'excerpt'  => "Comparatif detaille des deux grands outils de design en 2024.",
                'content'  => "<p>Le choix d'un outil de design est crucial pour la productivite.</p>",
                'status'   => 'published',
                'featured' => false,
                'category' => $categories[1],
                'views'    => 430,
            ],
            [
                'title'    => 'Brouillon : Guide Git avance',
                'excerpt'  => "Rebase interactif, cherry-pick, stash — tout ce que vous devez maitriser.",
                'content'  => "<p>Contenu en cours de redaction...</p>",
                'status'   => 'draft',
                'featured' => false,
                'category' => $categories[2],
                'views'    => 0,
            ],
        ];

        foreach ($posts as $data) {
            $category = $data['category'];
            unset($data['category']);

            $data['slug']        = Str::slug($data['title']);
            $data['user_id']     = $admin->id;
            $data['category_id'] = $category->id;

            if ($data['status'] === 'published') {
                $data['published_at'] = now()->subDays(rand(1, 60));
            }

            $post = Post::firstOrCreate(['slug' => $data['slug']], $data);

            if ($post->wasRecentlyCreated && $data['status'] === 'published') {
                foreach (range(1, rand(2, 4)) as $i) {
                    Comment::create([
                        'post_id'      => $post->id,
                        'author_name'  => "Lecteur {$i}",
                        'author_email' => "lecteur{$i}@example.com",
                        'content'      => "Super article, merci pour ce partage !",
                        'approved'     => $i !== 1,
                    ]);
                }
            }
        }

        $this->command->info('Seeder OK. Compte : admin@blog.com / password');
    }
}
