<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('post_id')->constrained()->cascadeOnDelete();
            $table->string('author_name');
            $table->string('author_email');
            $table->text('content');
            $table->boolean('approved')->default(false);
            $table->timestamps();

            $table->index(['post_id', 'approved']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('comments');
    }
};
